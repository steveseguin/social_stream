# Social Stream - Neutron theme

Recommended resolution on OBS:  
> `stream.html`: 1920x1080  
> `chatOnly.html`: 430x650

Why is it called Neutron?  
> The background image is from [here](https://github.com/xcruxiex/themes),  
> and one of its themes is called Neutron.

Preview:
> ![chatOnly.html](https://raw.githubusercontent.com/as2648as/social_stream/main/themes/Neutron/preview.png)  
> ![stream.html](https://raw.githubusercontent.com/as2648as/social_stream/main/themes/Neutron/preview_stream.png)
