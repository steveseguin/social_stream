function applyCustomActions(data){
	var tid = false;
	if (data.tid){tid = data.tid;}
	
	if (urlParams.has("auto1")){
		if (data.chatmessage === "1"){
			if (Date.now() - messageTimeout > 60000){ // respond to "1" with a "1" automatically; at most 1 time per minute.
				messageTimeout = Date.now();
				if (data.chatname.toLowerCase() === "pyka"){
					respondP2P("1 <3 <3 <3", tid);
				} else if (data.chatname.toLowerCase() !== "evarate"){
					respondP2P("1", tid);
				}
			}
		}
	} else if (urlParams.has("autocheer")){
		if (data.hasDonation){
			if (Date.now() - messageTimeout > 5000){ // respond to "1" with a "1" automatically; at most 1 time per minute.
				messageTimeout = Date.now();
				respondP2P("cheer100", tid);
			}
		}
	} else if (urlParams.has("ollama")){
		processMessageWithOllama(data);
	}
	
}
	
let isProcessing = false;
const lastResponseTime = {};

function processMessageWithOllama(data) {
	return new Promise((resolve, reject) => {
		const currentTime = Date.now();
		
		if (lastResponseTime[data.tid] && (currentTime - lastResponseTime[data.tid] < 5000)) {
			resolve(); // Skip this message if we've responded recently
			return;
		}

		if (isProcessing) {
			resolve();
			return;
		}

		isProcessing = true;

		const xhr = new XMLHttpRequest();
		xhr.open('POST', 'https://yourserver.com/api/generate', true);
		xhr.setRequestHeader('Content-Type', 'application/json');
		
		xhr.onload = function() {
			if (xhr.status === 200) {
				try {
					const result = JSON.parse(xhr.responseText);
					const aiResponse = result.response.trim();
					
					

					if (!aiResponse.includes("NO_RESPONSE")) {
						const msg = {
							tid: data.tid,
							response: aiResponse,
						};
						respondP2P(msg);
						lastResponseTime[data.tid] = currentTime;
					}
				} catch (error) {
					console.error('Error parsing response:', error);
				}
			} else {
				console.error('Request failed. Status:', xhr.status);
			}

			isProcessing = false;
			resolve();
		};

		xhr.onerror = function() {
			console.error('Request failed. Network error.');
			isProcessing = false;
			reject(new Error('Network error'));
		};

		const requestData = JSON.stringify({
			model: "llama3",
			prompt: `You are an AI assistant in an chat room for the audience of a live video stream. Your task is to decide whether to respond to the following message. If you think a response is warranted (e.g., the message is directed at you, or you have a witty comment), provide a short, engaging response. If you don't think a response is necessary, simply respond with "NO_RESPONSE", and nothing else.

User ${data.chatname} says: ${data.chatmessage}

Your decision and potential response:`
		});

		xhr.send(requestData);
	});
}
